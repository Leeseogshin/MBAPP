package com.example.task1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void calllogin(View view) {
    }
    public static final int REQUEST_CODE_MENU=101;

    EditText etid;
    EditText etpw;

    //onActivityResult 사용, 컨트롤+O 눌러서 찾으면 있음, 클래스 안에서 사용할 것.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE_MENU) {
            Toast.makeText(getApplicationContext(),
                    "onActivityResult 메서드 호출됨. 요청코드 : " + requestCode + ", 결과코드 " + resultCode, Toast.LENGTH_LONG).show();

            if(resultCode == RESULT_OK) {
                String name = data.getStringExtra("name");
                Toast.makeText(getApplicationContext(), "응답으로 전달된 name : " + name, Toast.LENGTH_LONG).show();

            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // etid=findViewById(R.id.inputid);
        // String etid.getText()

// 온클릭이벤트를 통해, 클릭했을 때 로그인 결과를 먼저 보여주기 위해  
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //id의 EditText 객체를 얻어온다.
                etid = findViewById(R.id.inputid);

                //pw의 EditText 객체를 얻어온다.
                etpw = findViewById(R.id.inputpw);

                //문자열 inputid에 id(EditText)객체로 부터 getText()를 호출한다.
                String inputid = etid.getText().toString();

                //문자열 inputpw에 pw(EditText)객체로 부터 getText()를 호출한다.
                String inputpw = etpw.getText().toString();

                //inputid는 "test" 그리고 inputpw는 "test"인 경우만 성공 아니면 실패

                if (inputid.equals("leeseongshin") && (inputpw.equals("leeseongshin"))){
                    Toast.makeText(getApplicationContext(),"로그인성공",Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(getApplicationContext(), airport.class);
                    startActivityForResult(intent, REQUEST_CODE_MENU);

                }
                else{
                    Toast.makeText(getApplicationContext(),"로그인실패",Toast.LENGTH_LONG).show();
                }


            }
        });
    }


}

